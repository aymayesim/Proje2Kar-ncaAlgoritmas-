
USAK_ADDRESSES = [
    "Kemalöz Mahallesi, Uşak",
    "Elmalidere Mahallesi, Uşak",
    "Kurtuluş Mahallesi, Uşak",
    "Atatürk Mahallesi, Uşak",
    "Aybek Mahallesi, Uşak",
    "Karaağaç Mahallesi, Uşak",
    "Dikilitaş Mahallesi, Uşak",
    "Işık Mahallesi, Uşak",
    "Fatih Mahallesi, Uşak",
    "Fevzi Çakmak Mahallesi, Uşak",
    "Sarayaltı Mahallesi, Uşak",
    "Bozkurt Mahallesi, Uşak",
    "Cumhuriyet Mahallesi, Uşak",
    "Durak Mahallesi, Uşak",
    "Mehmet Akif Ersoy Mahallesi, Uşak"
]
