# Karınca Kolonisi Algoritması ile Uşak Elektrik Arızaları Rota Optimizasyonu

Bu projede, Uşak ilinde 15 farklı mahallede aynı anda gelen elektrik arızalarına
giden tek bir teknik ekibin **toplam yolu en aza indiren rotası**,
Karınca Kolonisi Algoritması (Ant Colony Optimization, ACO) ile yaklaşık olarak hesaplanmıştır.

## Senaryo

Elektrik firması, Uşak ilinde aşağıdaki 15 mahallede aynı anda arıza bildirimi almıştır.
Tek bir ekip, tüm mahalleleri dolaşıp arızalara müdahale edecektir. Amaç,
başlangıç noktasından çıkıp tüm mahalleleri dolaşan **en kısa turu** bulmaktır.

## Kullanılan Teknolojiler

- Python
- Google Maps Geocoding API (adres → koordinat)
- Haversine formülü (kuş uçuşu mesafe hesabı)
- Karınca Kolonisi Algoritması (ACO)
- Streamlit (web arayüzü)
- Matplotlib (rota ve yakınsama grafikleri)

## Klasör Yapısı

```text
aco_usak_elektrik_rutasi/
│── main.py              # Streamlit ana uygulama
│── config.py            # Varsayılan ACO parametreleri
│── requirements.txt     # Gerekli Python paketleri
│
├── data/
│   ├── addresses.py         # Uşak mahalle adresleri listesi
│   └── google_maps_utils.py # Google Maps Geocoding API fonksiyonları
│
├── core/
│   ├── haversine.py         # Kuş uçuşu mesafe ve mesafe matrisi
│   └── ant_algorithm.py     # Karınca Kolonisi Algoritması
│
├── visual/
│   └── plotting.py          # Rota ve yakınsama grafikleri
│
├── .streamlit/
│   └── secrets.toml         # (İsteğe bağlı) Google API anahtarı için
│
└── figure/                  # (İsteğe bağlı) çıktı grafikleri
