
# Varsayılan ACO Parametreleri
DEFAULT_ANT_COUNT = 30
DEFAULT_ITERATIONS = 80
DEFAULT_ALPHA = 1.0       # feromon etkisi
DEFAULT_BETA = 2.0        # sezgisel bilgi etkisi
DEFAULT_RHO = 0.5         # buharlaşma oranı
DEFAULT_Q = 100           # feromon birikim katsayısı
